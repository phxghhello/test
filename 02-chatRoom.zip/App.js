// 创建一个服务器

// 导入 express 并且创建一个 express 对象
var app = require('express')();
// 导入了 http 核心模块，使用它使用一个基于 express 的 http 对象
var http = require('http').createServer(app);
// 创建一个 io 对象
var io = require('socket.io')(http);

// 设置路由：
//  根目录：
app.get('/', function (req, res) {
    // 返回一个静态页面
    // res.sendFile(__dirname + '/page/client.html')
    // 返回数据
    res.send({
        data: 'hello world!'
    })
});

// io.on('connect', client => {
//     console.log("连接成功");
//     client.emit("message", "你好啊！赛利亚");
// })

// 接收客户端的 websocket 连接
io.on('connection', function (socket) { // socket 指的就是此时连接上来的客户端对象
    console.log('连接成功', '客户端连接：' + socket.id)
    socket.emit("connect", '你好connect!');
    socket.emit("initmessage", '你好message!');
    // 接收客户端的消息
    socket.on('message', msg => {
        console.log(msg)
        // 将消息返回给客户端
        // io.emit('chat message', msg)
        socket.emit('chat message', '输出' + msg)
        io.emit('chat message', '服务输出' + msg)
    })
})

// 开启服务器
http.listen(3000, function () {
    console.log('listening on *:3000');
});
