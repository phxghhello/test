import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
const path = require("path");

// ANT DESIGN按需导入
import Components from "unplugin-vue-components/vite";
import { AntDesignVueResolver } from "unplugin-vue-components/resolvers";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    vue(),
    Components({
      resolvers: [AntDesignVueResolver()],
    }),
  ],
   // 设置资源路径别名
  resolve: {
    alias: [
      //   配置别名
      {
        find: "@",
        replacement: path.resolve(__dirname, "src"),
      },
    ],
  },
  // 如果接口有跨域问题，可以设置服务器代理
  server: {
    proxy: {
      //   "/api": "http://api.cpnegx.cn/finance",
    },
  },
});
