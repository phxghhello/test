<template>
  <a-tabs v-model:activeKey="tabData.customActiveKey" @change="handleTabClick">
    <a-tab-pane key="subscribing" tab="认购费率">
        <subscribing></subscribing>
    </a-tab-pane>
    <a-tab-pane key="purchasing" tab="申购费率">
        <purchasing></purchasing>
    </a-tab-pane>
    <a-tab-pane key="redeming" tab="赎回费率">
        <redeming></redeming>
    </a-tab-pane>
    <template #leftExtra>
      <div class="left-fund-type">
        <a-select
          ref="select"
          v-model:value="selectedFundType"
          style="width: 150px"
          :options="fundTypeOptions"
          option-label-prop="label"
          @change="handleChange"
        >
          <template #option="{ label, optLabel }">
            {{ optLabel || label }}
          </template>
        </a-select>
      </div>
    </template>
  </a-tabs>
</template>
<script setup>
import subscribing from "@/components/subscribing.vue";
import purchasing from "@/components/purchasing.vue";
import redeming from "@/components/redeming.vue";
import { reactive, ref } from "vue";
const fundTypeOptions = ref([
  {
    label: "基金产品",
    optLabel: "全部",
    value: "all",
  },
  {
    label: "混合型",
    value: "1",
  },
  {
    label: "股票型",
    value: "2",
  },
  {
    label: "债券型",
    value: "3",
  },
  {
    label: "指数型",
    value: "4",
  },
  {
    label: "QDII型",
    value: "5",
  },
  {
    label: "FOF型",
    value: "6",
  },
  {
    label: "货币型",
    value: "7",
  },
]);
const selectedFundType = ref("all");

const tabData = reactive({
  customActiveKey: "purchasing",
});

// 方法
function handleTabClick(key) {
  tabData.customActiveKey = key;
}

const handleChange = (value) => {
  console.log(`selected ${value}`);
};
</script>

<style lang="less" scoped>
.left-fund-type {
  margin: 5px 10px;
}
</style>
