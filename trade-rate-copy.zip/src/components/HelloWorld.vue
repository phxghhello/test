<script setup>
</script>

<template>
  <p>
  hello vite
  </p>
</template>

<style scoped>
</style>
