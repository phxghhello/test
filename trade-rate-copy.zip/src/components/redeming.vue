<template>
  <div>
  赎回费率
  </div>
</template>

<script setup>
</script>

<style lang="less" scoped>
</style>
