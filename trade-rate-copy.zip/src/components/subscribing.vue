<template>
  <div class="subscribing-wrapper">
    <a-table
      :columns="columns"
      :data-source="data"
      bordered
      size="middle"
      :pagination="false"
      rowClassName="fund-row"
    >
      <template #headerCell="{ column }">
        <template v-if="column.key === 'fundNameCode'">
          <span>基金名称</span><br />
          <span>代码</span>
        </template>
      </template>
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'fundNameCode'">
          <div
            :class="{ 'type-row': record.fundNameCode.indexOf('以上为') === 0 }"
            v-html="record.fundNameCode"
          ></div>
        </template>
        <template v-if="column.key === 'amountList'">
          <div
            v-for="(item, index) in record.amountList"
            :key="index"
            class="sub-cell"
          >
            {{ item }}
          </div>
        </template>
        <template v-if="column.key === 'rateList'">
          <div
            v-for="(item, index) in record.rateList"
            :key="index"
            class="sub-cell"
          >
            {{ item }}
          </div>
        </template>
        <template v-if="column.key === 'gongHangList'">
          <div
            v-for="(item, index) in record.gongHangList"
            :key="index"
            class="sub-cell"
          >
            {{ item }}
          </div>
        </template>
        <template v-if="column.key === 'nongHangList'">
          <div
            v-for="(item, index) in record.nongHangList"
            :key="index"
            class="sub-cell"
          >
            {{ item }}
          </div>
        </template>
        <template v-if="column.key === 'jianHangList'">
          <div
            v-for="(item, index) in record.jianHangList"
            :key="index"
            class="sub-cell"
          >
            {{ item }}
          </div>
        </template>
        <template v-if="column.key === 'zhaoHangList'">
          <div
            v-for="(item, index) in record.zhaoHangList"
            :key="index"
            class="sub-cell"
          >
            {{ item }}
          </div>
        </template>
        <template v-if="column.key === 'tongLianList'">
          <div
            v-for="(item, index) in record.tongLianList"
            :key="index"
            class="sub-cell"
          >
            {{ item }}
          </div>
        </template>
        <template v-if="column.key === 'xianJinBaoList'">
          <div
            v-for="(item, index) in record.xianJinBaoList"
            :key="index"
            class="sub-cell"
          >
            {{ item }}
          </div>
        </template>
      </template>
    </a-table>
  </div>
</template>

<script setup>
// 接收从父组件传递的数据
// defineProps({
//   tableData: Array
// })
import { reactive, ref } from "vue";
const sharedOnCell = (record, rowIndex, column) => {
  if (record.fundNameCode.indexOf("以上为") === 0) {
    return { colSpan: 10 };
  }
};
const sharedOnCellNone = (record, rowIndex, column) => {
  if (record.fundNameCode.indexOf("以上为") === 0) {
    return { colSpan: 0 };
  }
};
const columns = [
  {
    title: "基金名称 / 代码",
    dataIndex: "fundNameCode",
    key: "fundNameCode",
    width: 200,
    fixed: "left",
    customCell: sharedOnCell,
  },
  {
    title: "基金类型",
    dataIndex: "fundType",
    key: "fundType",
    width: 80,
    customCell: sharedOnCellNone,
  },
  {
    title: "购买金额",
    dataIndex: "amountList",
    key: "amountList",
    width: 170,
    customCell: sharedOnCellNone,
  },
  {
    title: "标准认购费率",
    dataIndex: "rateList",
    key: "rateList",
    width: 140,
    customCell: sharedOnCellNone,
  },
  {
    title: "银行卡认购基金",
    children: [
      {
        title: "工行直联",
        dataIndex: "gongHangList",
        key: "gongHangList",
        width: 140,
        customCell: sharedOnCellNone,
      },
      {
        title: "农行直联",
        dataIndex: "nongHangList",
        key: "nongHangList",
        width: 140,
        customCell: sharedOnCellNone,
      },
      {
        title: "建行直联",
        dataIndex: "jianHangList",
        key: "jianHangList",
        width: 140,
        customCell: sharedOnCellNone,
      },
      {
        title: "招行直联",
        dataIndex: "zhaoHangList",
        key: "zhaoHangList",
        width: 140,
        customCell: sharedOnCellNone,
      },
      {
        title: "通联快捷",
        dataIndex: "tongLianList",
        key: "tongLianList",
        width: 140,
        customCell: sharedOnCellNone,
      },
    ],
  },
  {
    title: "现金宝买基金",
    dataIndex: "xianJinBaoList",
    key: "xianJinBaoList",
    // width: 120,
    // fixed: 'right',
  },
];
const dataSource = [...Array(50)].map((_, i) => ({
  key: i,
  fundNameCode: "景顺长城安景一年一年持有期混合C<br/>013226",
  fundType: "股票型",
  amount: "M≥1",
  amountList: ["M＜100万", "100万≤M＜200万", "200万≤M＜500万", "M≥500万"],
  rateList: ["1.000%", "0.600%", "0.200%", "1000元/笔"],
  gongHangList: ["1.000%", "0.600%", "0.200%", "1000元/笔"],
  nongHangList: ["1.000%", "0.600%", "0.200%", "1000元/笔"],
  jianHangList: ["1.000%", "0.600%", "0.200%", "1000元/笔"],
  zhaoHangList: ["1.000%", "0.600%", "0.200%", "1000元/笔"],
  tongLianList: ["1.000%", "0.600%", "0.200%", "1000元/笔"],
  xianJinBaoList: ["1.000%", "0.600%", "0.200%", "1000元/笔"],
}));
dataSource.push({
  fundNameCode: "以上为股票型基金",
});
const data = dataSource;
</script>

<style lang="less">
.subscribing-wrapper {
  margin: 0px 10px 20px;
  .ant-table {
    .ant-table-thead {
      tr {
        th {
          background-color: #250f91;
          color: #f0f0f0;
          &.ant-table-cell {
            text-align: center;
          }
        }
      }
    }
    .ant-table-tbody {
      .ant-table-row {
        &.fund-row {
          .ant-table-cell {
            padding: 0;
            .sub-cell {
              text-align: center;
              padding: 6px 0px;
              &:not(:last-child) {
                border-bottom: 1px solid #f0f0f0;
              }
            }
          }
          .type-row {
            text-align: center;
            background-color: #c2c2a0;
          }
        }
      }
    }
  }
}
</style>
