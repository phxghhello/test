module.exports = {
    publicPath:'./'
}